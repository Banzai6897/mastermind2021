
from random import randint
import partida
import mysql.connector
from mysql.connector import Error
                                     
##################################################################################
# NOME: main
# OBJETIVO: Função que inicializa o jogo
##################################################################################
def main():
    run = True

    user = partida.criaUserName()

    nivel = partida.qualNivel()

    print("\n* Ok", user, "Vamos começar! *")
    qtdJogadas = partida.oJogo(nivel[0],nivel[1]) 
    if qtdJogadas <= 7:
        resultado = "Ganhou"
    elif qtdJogadas > 7:
        resultado = "Perdeu"
    print("\n* Fim! Obrigado por jogar MasterMind! *")

    record = (user, qtdJogadas,resultado)

    try:
        connection = mysql.connector.connect(host='localhost', 
                                            database ='partidasMastermind', 
                                            user='root', 
                                            password=' ')

        cursor = connection.cursor()

        
        if nivel==(8,4):
            sql = ("""INSERT INTO nivel1 (user, tentativas, resultado) VALUES (%s, %s, %s)""")
            cursor.execute(sql, record)
        elif nivel==(10,5):
            sql = ("""INSERT INTO nivel2 (user, tentativas, resultado) VALUES (%s, %s, %s)""")
            cursor.execute(sql, record)
        elif nivel==(12,6):
            sql = ("""INSERT INTO nivel3 (user, tentativas, resultado) VALUES (%s, %s, %s)""")
            cursor.execute(sql, record)
        connection.commit()
        print(cursor.rowcount, "Registro Inserido")
        cursor.close()
        
    except Error as e:
        print("Erro de conexao", e)
    finally:
        if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("Conexao Encerrada")
        
    return


if __name__ == "__main__":
    main()
