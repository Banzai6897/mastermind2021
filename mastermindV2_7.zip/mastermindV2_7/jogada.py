##################################################################################
# NOME: jogadaUsuario
# OBJETIVO: Função que recebe a quantidade de algarismos da senha e pede para o
#           usuário informar via teclado os digitos do seu chute
##################################################################################
def jogadaUsuario(numAlgarismos):
    return input("\nEntre com os %d digitos da senha: "%numAlgarismos)