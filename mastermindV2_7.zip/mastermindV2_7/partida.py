
from random import randint
import jogada 
import feedback

##################################################################################
# NOME: qtdAlgarismos
# OBJETIVO: Função que recebe uma senha e retorna a quantidade de algarismo do
#           número, usando a funcao "len"
##################################################################################
def qtdAlgarismos(senha):
    return len(senha)
    
##################################################################################
# NOME: geraSenha
# OBJETIVO: Função que gera uma senha de forma aleatoria, utilizando a biblioteca  
#           random, com a quantidade de algarismos recebidos como parâmetro
##################################################################################
def geraSenha(numAlgarismos):
    dig01 = randint(1,7)
    dig02 = randint(1,7)
    dig03 = randint(1,7)
    dig04 = randint(1,7)
    dig05 = randint(1,7)
    dig06 = randint(1,7)
    strDig01 = str(dig01)
    strDig02 = str(dig02)
    strDig03 = str(dig03)
    strDig04 = str(dig04)
    strDig05 = str(dig05)
    strDig06 = str(dig06)

    if numAlgarismos == 4:
        senha = strDig02 + strDig01 + strDig03 + strDig04
    elif numAlgarismos == 5:
        senha = strDig01 + strDig04 + strDig03 + strDig05  + strDig02
    elif numAlgarismos == 6:
        senha = strDig01 + strDig02 + strDig04 + strDig06  + strDig05 + strDig03
    
    return senha

