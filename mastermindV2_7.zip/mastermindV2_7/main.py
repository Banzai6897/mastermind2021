
from random import randint
import partida
import jogada
import feedback
import interface as ui

import mysql.connector
import connection
from mysql.connector import Error



##################################################################################
# NOME: oJogo
# OBJETIVO: Função principal que roda o jogo como um todo
##################################################################################
def oJogo(jogadas,numAlgarismos):

    senha = partida.geraSenha(numAlgarismos)
    print(senha)
    global qtdJogadas
    global resultado
    qtdJogadas = 1
    while (qtdJogadas <= jogadas):
        ui.jogadaUsuario(ui.root) 
        senhaChute = ui.jogadaRetorno
        feedbackJogada = feedback.checaJogada(senha,senhaChute,numAlgarismos)
        ui.desenhaFeedback(ui.root, feedbackJogada)
        while feedbackJogada == -1:
            ui.jogadaUsuario(ui.root)
            senhaChute = ui.jogadaRetorno
            feedbackJogada = feedback.checaJogada(senha,senhaChute,numAlgarismos)
            ui.desenhaFeedback(ui.root, feedbackJogada)
        if feedbackJogada == senha:
            print("Parabéns, você venceu!")
            resultado = "Ganhou"
            return qtdJogadas, resultado 
        
        print("->",feedbackJogada)
        print("-> Restam %d jogadas!"%(jogadas-qtdJogadas))

        qtdJogadas += 1
    
    print("Game Over! Você excedeu o número de tentativas!")
    resultado = "Perdeu"
    return qtdJogadas - 1, resultado

##################################################################################
# NOME: main
# OBJETIVO: Função que inicializa o jogo
##################################################################################
def main():
    
    #run = True

    #while run == True:
   
        #print("\n* Ok", user, "Vamos começar! *")
    #dados = gr.desenhaPerguntaDados()
    
    
    #qtdJogadas, resultado = oJogo(ui.x[0],ui.x[1])
    #qtdJogadas, resultado = oJogo(ui.x[0],ui.x[1])
    connection.registroPartidas(ui.x, ui.userRetorno, qtdJogadas, resultado)
    
    print("\Fim! Obrigado por jogar MasterMind! *\n")
    
    
    #run = False
    return 


if __name__ == "__main__":
    main()
    