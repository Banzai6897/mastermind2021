
import main
from tkinter import * 
from PIL import ImageTk, Image
import connection


from tkinter import *
from tkinter import messagebox
import tkinter as tk
from tkinter import ttk

#selecao de nivel
root = Tk()
root.geometry("300x200")
root.resizable(False, False)
root.title("Selecao de nivel")

label = ttk.Label(text="Selecione o nível do jogo:")
label.pack(fill=tk.X, padx=5, pady=5)
nivelSelecionado = tk.StringVar()
comboNivel = ttk.Combobox(root, textvariable=nivelSelecionado)
valores = [(8,4),(10,5),(12,6)]
valor = [()]
comboNivel['values'] = ['Nivel 1', 'Nivel 2', 'Nivel 3']
comboNivel['state'] = 'readonly'
comboNivel.pack(fill=tk.X, padx=5, pady=5)


def selecionaNivel(event):
    global x 
    x = valores[comboNivel.current()]
    label.after(500, label.destroy())
    comboNivel.after(500, comboNivel.destroy())
    return x
 
comboNivel.bind('<<ComboboxSelected>>', selecionaNivel)


#definicao do nome de usuario

def incluiUsuario(root):
    frame = Frame()
    userLabel = Label(frame, text = "Usuario (ate 8 caracteres): ")
    userEntry = Entry(frame, textvariable="")
    def insere():
        user = userEntry.get().strip()
        retorno = retornaUserGlobal(user)
        userEntry.delete(0, END)
        print(retorno)
        userEntry.after(500, userEntry.destroy())
        userLabel.after(500, userLabel.destroy())
        frame.after(500, frame.destroy())
        main.oJogo(x[0], x[1])
    userLabel.pack(fill=tk.X,padx=5, pady=5)
    userEntry.pack(fill=tk.X, padx=5, pady=5)
    frame.pack(fill=tk.X, padx=5, pady=5)
    root.bind('<Return>', lambda a : configuraEnter(a, insere))
    
def retornaUserGlobal(user):
    global userRetorno
    userRetorno = user
    
    return userRetorno

def configuraEnter(event, funcao):
    key = event.keysym
    if key == 'Return':
        funcao()
#Jogada do usuario:

def jogadaUsuario(root):
    frame = Frame()
    jogadaLabel = Label(frame, text = "Senha com dígitos de 1 a 7:")
    jogadaEntry = Entry(frame, textvariable="")
    def insere2():
        jogada = jogadaEntry.get().strip()
        retorno = retornaJogadaGlobal(jogada)
        jogadaEntry.delete(0, END)
        print(retorno)
        jogadaEntry.after(1000, jogadaEntry.destroy())
        jogadaLabel.after(1000, jogadaLabel.destroy())
        frame.after(1000, frame.destroy())
    jogadaLabel.pack(fill=tk.X,padx=5, pady=5)
    jogadaEntry.pack(fill=tk.X, padx=5, pady=5)
    frame.pack(fill=tk.X, padx=5, pady=5)
    root.bind('<Return>', lambda a : configuraEnter(a, insere2))

def retornaJogadaGlobal(jogada):
    global jogadaRetorno
    jogadaRetorno = jogada
    print(jogada)
    return jogadaRetorno

def desenhaFeedback(root, feedback):
    frame = Frame()
    feedbackLabel = Label(frame, text = feedback)
    feedbackLabel.pack(fill=tk.X,padx=5, pady=5)
    #feedbackLabel.after(7000, feedbackLabel.destroy())
    #frame.after(7000, frame.destroy())
incluiUsuario(root)

root.mainloop()      
connection.registroPartidas(x, userRetorno, main.qtdJogadas, main.resultado)


##################################################################################
# NOME: qualNivel
# OBJETIVO: Função que pergunta ao usuario em qual nivel deseja jogar
##################################################################################









