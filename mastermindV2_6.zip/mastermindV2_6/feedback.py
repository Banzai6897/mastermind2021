import random
import partida

##################################################################################
# NOME: checaAlgarismos
# OBJETIVO: Função que recebe uma senha a quantidade de algarismos que ela deve
#           ter e, retorna: True, se a senha tem a quantidade exata de digitos
#                           False, se ela tem uma quatidade incorreta de digitos.
# ACOPLAMENTO: Recebe a senha informada pelo jogador na sua jogada, o número de
#              algarismos, definido pelo nível de dificuldade decidido pelo jogador,
#              e retorna um aviso, que é definido se o número de digitos da jogadas
#              é igual ao número de algarismos.
# ASSERTIVA DE ENTRADA: É necessário receber um variável do tipo string, para a senha
#                       chute e uma variável do tipo inteiro para o numero de
#                       algarismos.
# ASSERTIVA DE SAIDA: Retorna 1 ou 0, de acordo com a condição deinida, se a senha
#                     do chute for igual ao número de algarismos.
# REQUISITOS: É necessário que o jogador tenha feito uma jogada, senha
#             chute, e tenha definido o número de algarismos através
#             da escolha do nível de dificuldade.
##################################################################################
def checaAlgarismos(senhaChute,numAlgarismos):
    return partida.qtdAlgarismos(senhaChute) == numAlgarismos

##################################################################################
# NOME: checaJogada
# OBJETIVO: Função que recebe a senha chute do usuario e a verifica: exibindo uma
#           mensagem de erro ou retornando feedback da senha (acertos e erros)
# ACOPLAMENTO: Recebe a senha correta, a senha da jogada do usuario e o numero
#              de algarismos, definidos pela dificuldade. E retorna um feedeback
#              de acordo com os parametros recebidos.
# ASSERTIVAs DE ENTRADA: Os parametros devem ser passados no tipo correto, a senha
#                        e o chute do jogador deve ser uma string. O numero de
#                        algarismos deve ser to tipo inteiro.
# ASSERTIVAS DE SAIDA: Retorna um feedeback explicitando o número, caso esteja na
#                      posição correta com o número correto, ou um caractere de
#                      "?", caso seja um número correto porém na posição incorreta.
#                      Ou um caractere "X", caso o número esteja errado e a posição
#                      também esteja errada.
# REQUISITOS: É necessário que a senha correta tenha sido gerada no início da
#             execução do programa, além de que o jogador deve ter definido
#             corretamente o nível de dificuldade, definindo o número de algarismos,
#             e tenha realizado um chute de uma senha.
##################################################################################
def checaJogada(senha,senhaChute,numAlgarismos):

    if not checaAlgarismos(senhaChute,numAlgarismos):
        print("Quantidade de digitos incorreto!")
        return -1

    feedbackChute = ""
    for (pos,digito) in enumerate(senhaChute):

        if digito == senha[pos]:
            feedbackChute += digito
        elif digito in senha:
            feedbackChute += "?"
        else:
            feedbackChute += "X"

    return feedbackChute
