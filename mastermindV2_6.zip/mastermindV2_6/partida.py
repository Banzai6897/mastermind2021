from random import randint
import jogada
import feedback
##################################################################################
# NOME: criaUserName
# OBJETIVO: Recebe entrada de texto com nome do usuario e retorna string contendo o mesmo.
# ACOPLAMENTO: Retorna variavel com nome de usuario, utilizada posteriormente no modulo main e no
#              modulo connection, para identificar o jogador durante o armazenamento de dados das partidas.
# ASSERTIVAS DE SAIDA: Usuario deve inserir texto nao vazio e menor ou igual a 8 caracteres.
# INTERFACE COM USUARIO: Solicita entrada de texto com instrucoes para a insercao.
# REQUISITOS: Usuario deve inserir algum texto de entrada.
# HIPOTESES: Usuario deve concordar em armazenar dados referentes as partidas no servidor local,
#            assim como um servidor deve existir na maquina para que tais dados sejam armazenados.
# RESTRICOES: Usuario deve inserir texto menor ou igual a 8 caracteres.
##################################################################################
def criaUserName():
    user = str(input("Bem vind@ ao jogo\n\n\tM\tA\tS\tT\tE\tR\tM\tI\tN\tD\n\n\ninsira um nome de usuário com até 8 caracteres para iniciar o jogo."))
    return user
##################################################################################
# NOME: qtdAlgarismos
# OBJETIVO: Medir o tamanho de uma senha.
# ACOPLAMENTO: Recebe senha e retorna o tamanho.
# ASSERTIVAS DE ENTRADA: Deve rececber uma string com a senha que se deseja medir.
# ASSERTIVAS DE SAIDA: Retorna inteiro com tamanho da string recebida.
# REQUISITOS: Deve receber string e retornar inteiro.
##################################################################################
def qtdAlgarismos(senha):
    return len(senha)

##################################################################################
# NOME: geraSenha
# OBJETIVO: Gera senha com digitos aleatorios entre 1 e 7 (repetidos ou nao)
#           para que o usuario tente acertar.
# ACOPLAMENTO: Recebe numero de algarismos referente ao nivel de dificuldade
#              selecionado pelo usuario.
# ASSERTIVAS DE ENTRADA: numero de algarismos recebido deve ter o valor 4, 5 ou 6.
# ASSERTIVAS DE SAIDA: As strings com os digitos aleatorios devem ser concatenadas
#                      em uma so string, com tamanho dependente do nivel de dificuldade
#                      selecionado pelo usuario.
# REQUISITOS:Recebe inteiro entre 4 e 6.
# HIPOTESES: O usuario deve ter escolhido um nivel para jogar.
##################################################################################
def geraSenha(numAlgarismos):
    dig01 = randint(1,7)
    dig02 = randint(1,7)
    dig03 = randint(1,7)
    dig04 = randint(1,7)
    dig05 = randint(1,7)
    dig06 = randint(1,7)
    strDig01 = str(dig01)
    strDig02 = str(dig02)
    strDig03 = str(dig03)
    strDig04 = str(dig04)
    strDig05 = str(dig05)
    strDig06 = str(dig06)

    if numAlgarismos == 4:
        senha = strDig02 + strDig01 + strDig03 + strDig04
    elif numAlgarismos == 5:
        senha = strDig01 + strDig04 + strDig03 + strDig05  + strDig02
    elif numAlgarismos == 6:
        senha = strDig01 + strDig02 + strDig04 + strDig06  + strDig05 + strDig03

    return senha
##################################################################################
# NOME: oJogo
# OBJETIVO: Chama as outras funcoes de acesso na ordem devida, resumindo o loop
#           do jogo a execucao da funcao.
# ACOPLAMENTO: Recebe tamanho da senha gerada e quantidade de jogadas disponiveis
#              para o usuario, obtidas apos a selecao de nivel pelo usuario.
#              Retorna a quantidade de jogadas e resultado da partida para armazenamento na
#              database do sistema.
# ASSERTIVAS DE ENTRADA: Recebe 8, 10 ou 12 como numero de jogadas e 4, 5 ou 6 como
#                        quantidade de digitos da senha para os respectivos niveis 1, 2 e 3.
# ASSERTIVAS DE SAIDA: Usuario excede o numero de tentativas ou acerta a senha para que
#                      a funcao retorne a quantidade jogadas empregadas na partida e o resultado final.
# INTERFACE COM O USUARIO: Usuario recebe o feedback de cada jogada inserida e o resultado da partida.
# REQUISITOS: Usuario deve ter selecionado o nivel.
# HIPOTESES: Nivel selecionado entre 1 e 3.
##################################################################################
def oJogo(jogadas,numAlgarismos):

    senha = geraSenha(numAlgarismos)
    print(senha)


    qtdJogadas = 1
    while (qtdJogadas <= jogadas):

        senhaChute = jogada.jogadaUsuario(numAlgarismos)
        feedbackJogada = feedback.checaJogada(senha,senhaChute,numAlgarismos)

        #caso do usuario inserir numero incorreto de digitos
        while feedbackJogada == -1:
            senhaChute = jogada.jogadaUsuario(numAlgarismos)
            feedbackJogada = feedback.checaJogada(senha,senhaChute,numAlgarismos)
        #Usuario vence o jogo
        if feedbackJogada == senha:
            print("Parabéns, você venceu!")
            resultado = "Ganhou"
            return qtdJogadas, resultado

        print("->",feedbackJogada)
        print("-> Restam %d jogadas!"%(jogadas-qtdJogadas))

        qtdJogadas += 1


    print("Game Over! Você excedeu o número de tentativas!")
    resultado = "Perdeu"

    return qtdJogadas - 1, resultado
##################################################################################
# NOME: nivelJogo
# OBJETIVO: Baseado na entrada do usuario, a funcao calcula a quantidade de tentativas
#           disponiveis para o usuario e o tamanho da senha gerada.
# ACOPLAMENTO: Recebe nivel selecionado pelo usuario e retorna tentativas e tamanho de senha.
# ASSERTIVAS DE ENTRADA: Recebe inteiro
# ASSERTIVAS DE SAIDA: nivel entre 1 e 3, caso diferente, retorna -1
# REQUISITOS: Depende da chamada de qualNivel()
# HIPOTESES: Usuario deseja jogar entre os 3 niveis de dificuldade propostos.
##################################################################################
def nivelJogo(nivel):

    if nivel == 1:
        return (8,4)
    elif nivel == 2:
        return (10,5)
    elif nivel == 3:
        return (12,6)
    else:
        return -1
##################################################################################
# NOME: qualNivel
# OBJETIVO: Induz o usuario a selecionar o nivel de dificuldade
# ACOPLAMENTO: retorna chamada de nivelJogo() com entrada do usuario como parametro.
# ASSERTIVAS DE SAIDA: Entrada do usuario entre 1 e 3.
# INTERFACE COM O USUARIO: Pede ao usuario que insira o nivel entre 1 e 3.
# REQUISITOS: nivelJogo() retornando tupla.
##################################################################################
def qualNivel():

    print("\nInforme o nível que deseja jogar (1,2 ou 3)")
    print("- (1) Fácil")
    print("- (2) Médio")
    print("- (3) Difícil")
    return nivelJogo(int(input("- Nível desejado: ")))
