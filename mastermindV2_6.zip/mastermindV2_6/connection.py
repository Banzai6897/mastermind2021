import mysql.connector
from mysql.connector import Error
from xml.etree import *
from xml.etree.ElementTree import *

##################################################################################
# NOME: criaBDmySQL
# OBJETIVO: Cria banco de dados para armazenamento das partidas caso o mesmo nao exista.
# ACOPLAMENTO: Valor referente ao sucesso ou fracasso na criacao do banco de dados.
# ASSERTIVAS DE SAIDA: Retorna 0 ou 1, conforme o sucesso na conexao com o banco de dados.
# REQUISITOS: Servidor deve estar atualizado e funcionando no sistema.
# HIPOTESES: Usuario utilizasenha e usuario "root" para logar no servidor mySql
##################################################################################

def criaDBmySQL():
    try:
        connection = mysql.connector.connect(host='localhost',
                                             user='root',
                                             password='banzaiPipeleme_0')
        cursor = connection.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS partidasMastermind2_6;")
        connection.commit()

    except Error as e:
        print("Erro de conexao", e)
        return 0

    finally:
        if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("Base de dados partidasMastermind2_6 criada ou existente em localhost. ")

    return 1

##################################################################################
# NOME: registroPartidas
# OBJETIVO: Insere dados das partidas na base, imprimindo os dados dos usuarios que jogaram no mesmo nivel
#           e chamando a funcao que gera um arquivo xml com os dados das partidas.
# ACOPLAMENTO: recebe nivel da partida, nome de usuario, quantidade de jogadas e resultado
# ASSERTIVAS DE ENTRADA: criaDBmySQL retornando 1 (conexao estavel), nivel entre 1 e 3, usuario com 8 ou menos caracteres,
#                        quantidade de jogadas menor que 8 e resultado contendo string com 6 digitos.
# REQUISITOS: Servidor deve estar atualizado e funcionando no sistema.
# HIPOTESES: Usuario utilizasenha e usuario "root" para logar no servidor mySql
##################################################################################
def registroPartidas(nivel, user, qtdJogadas, resultado):
    dbExiste = criaDBmySQL()
    if dbExiste == 1:
        record = (user, qtdJogadas,resultado)
        try:
            connection = mysql.connector.connect(host='localhost',
                                                 user='root',
                                                 database ='partidasMastermind2_6',
                                                 password='banzaiPipeleme_0',
                                                 )

            cursor = connection.cursor()

            cursor.execute("CREATE TABLE IF NOT EXISTS nivel1 (user VARCHAR(8), tentativas INT(1), resultado CHAR(6), PRIMARY KEY(user));")
            cursor.execute("CREATE TABLE IF NOT EXISTS nivel2 (user VARCHAR(8), tentativas INT(2), resultado CHAR(6), PRIMARY KEY(user));")
            cursor.execute("CREATE TABLE IF NOT EXISTS nivel3 (user VARCHAR(8), tentativas INT(2), resultado CHAR(6), PRIMARY KEY(user));")

            if nivel==(8,4):
                sql = ("""INSERT INTO nivel1 (user, tentativas, resultado) VALUES (%s, %s, %s);""")
                cursor.execute(sql, record)
            elif nivel==(10,5):
                sql = ("""INSERT INTO nivel2 (user, tentativas, resultado) VALUES (%s, %s, %s);""")
                cursor.execute(sql, record)
            elif nivel==(12,6):
                sql = ("""INSERT INTO nivel3 (user, tentativas, resultado) VALUES (%s, %s, %s);""")
                cursor.execute(sql, record)
            connection.commit()

            if nivel==(8,4):
                cursor.execute("SELECT * FROM nivel1")
                result = cursor.fetchall()
                nivelPartida = str(1)
                print("\n\tRANKING DOS USUARIOS QUE JOGARAM NESTA MAQUINA NO NIVEL", nivelPartida,  ":\n")
                print("\n\tUSUARIO - NUMERO DE  TENTATIVAS - RESULTADO FINAL\n")
            elif nivel ==(10,5):
                cursor.execute("SELECT * FROM nivel2")
                result = cursor.fetchall()
                nivelPartida = str(2)
                print("\n\tRANKING DOS USUARIOS QUE JOGARAM NESTA MAQUINA NO NIVEL", nivelPartida, ":\n")
                print("\n\tUSUARIO - NUMERO DE  TENTATIVAS - RESULTADO FINAL\n")
            elif nivel ==(12,6):
                cursor.execute("SELECT * FROM nivel3")
                result = cursor.fetchall()
                nivelPartida = str(3)
                print("\n\tRANKING DOS USUARIOS QUE JOGARAM NESTA MAQUINA NO NIVEL", nivelPartida, ":\n")
                print("\n\tUSUARIO - NUMERO DE  TENTATIVAS - RESULTADO FINAL\n")

            for row in result:
                print("\t", row, "\n")

            cursor.close()

        except Error as e:
            print("Erro de conexao", e)

        finally:
            if(connection.is_connected()):
                cursor.close()
                connection.close()
                print("Conexao Encerrada")
    elif dbExiste == 0:
        print("Erro na criacao da base de dados.")

    cria_xml(result, nivelPartida)
    return
##################################################################################
# NOME: cria_xml
# OBJETIVO: Gera arquivo .xml com dados das partidas jogadas no nivel selecionado durante a execucao
#           mais recente , contendo usuario, tentativas e resultado.
# ACOPLAMENTO: recebe nivel da partida e lista com dados das tuplas presentes no banco de dados
# ASSERTIVAS DE ENTRADA: cLista recebida maior que 0, nivel entre 1 e 3.
# REQUISITOS: Lista nao vazia gerada na funcao registroPartidas, nivel inserido pelo usuario.
##################################################################################
def cria_xml(lista, nivel):
    rootEl = Element("Mastermind - Relacao de Partidas no nivel " + nivel)

    for item in range(len(lista)):
        partida = SubElement(rootEl, "partida -> Usuario - Tentativas - Resultado")
        partida.text = str(lista[item])
    tree = ElementTree(rootEl)
    tree.write("partidas.xml", xml_declaration=True)
