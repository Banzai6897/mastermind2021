##################################################################################
# NOME: jogadaUsuario
# OBJETIVO: Função que recebe a quantidade de algarismos da senha e pede para o
#           usuário informar via teclado os digitos do seu chute.
# ACOPLAMENTO: Recebe o número de algarismos da senha, definidos apartir do nível
#              da dificuldade. Retorna um input para receber a jogada do usuário.
# ASSERTIVA DE ENTRADA: O usuário ter escolhido o nível de dificuldade, o que
#                       define o numero de algarismos.
# ASSERTIVA DE SAIDA: O usuário deve digitar uma jogada.
# INTERFACE COM O USUARIO: Usuário entra com uma jogada.
# REQUISITOS: A jogada digitada pelo usuário deve ser de acordo com o número de
#             dígitos estabelecidos pelo nível de dificuldade.
# HIPOTESES: Deve haver um usuário para entrar com as jogadas.
##################################################################################
def jogadaUsuario(numAlgarismos):
    return input("\nEntre com os %d digitos da senha: "%numAlgarismos)
